java -jar target/evaldropwizard-0.0.1-SNAPSHOT.jar server hello-world.yaml

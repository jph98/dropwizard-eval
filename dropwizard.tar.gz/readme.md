Dropwizard Intro
================

Makes use of:
* Jetty
* Jersey
* Jackson
* Guava
* Logback
* Codahale Metrics
* JDBI - http://www.jdbi.org/


Getting Started
http://dropwizard.codahale.com/getting-started/

User Manual
http://dropwizard.codahale.com/manual/#manual-index
 
Admin
http://localhost:8081/

Usage
http://localhost:8080/hello-world
http://localhost:8080/hello-world?name=Successful+Dropwizard+User